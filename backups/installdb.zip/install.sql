-- MySQL dump 10.11
--
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	5.0.92-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `keyName` varchar(100) NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` VALUES (1,'layout-footer','layout-footer','<div id=\"footer\">Copyright &copy; {$ProductTitle} 2011. All Rights Reserved.</div>\r\n'),(14,'box-login','box-login','<div class=\"box_container\">\r\n	<div id=\"userlogin\">\r\n		<h2><span>Member Login</span></h2>\r\n		<form action=\"/user/login\">\r\n			<div class=\"form_field\">\r\n				<strong>Username</strong>\r\n				<input type=\"text\" name=\"username\" />\r\n			</div>\r\n			<div class=\"clearthis\"> </div>\r\n			<div class=\"form_field\">\r\n				<strong>Password</strong>\r\n				<input type=\"password\" name=\"password\" />\r\n			</div>\r\n			<div class=\"clearthis\"> </div>\r\n			<div class=\"form_field\">\r\n				<input type=\"submit\" class=\"button\" value=\"Login\" />\r\n			</div>\r\n		</form>\r\n		<div id=\"link-password\">\r\n			<a href=\"/user/forgotpassword\">Forgot Password?</a>\r\n		</div>\r\n	</div>\r\n</div>'),(2,'layout-header','layout-header','<div id=\"header\">\r\n	<div id=\"logo\">\r\n		<div id=\"logo_text\">\r\n			<h1>{$ProductTitle}</h1>\r\n		</div>\r\n	</div>\r\n	\r\n	<div id=\"menubar\">\r\n		{menu}\r\n	</div>\r\n</div>\r\n'),(3,'layout-title','layout-title','<title>{$pageTitle}</title>\n<META NAME=\"title\" CONTENT=\"{$metaTitle}\">\n<META NAME=\"description\" CONTENT=\"{$metaDescription}\">\n<META NAME=\"keywords\" content=\"{$metaKeywords}\">\n\n<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"/favicon.ico\">'),(4,'layout-js','layout-js','<script type=\"text/javascript\">var httpUrl=\'{$httpUrl}\';</script>\r\n<script src=\"/bento/js/jquery.js\" type=\"text/javascript\"></script>\r\n<script src=\"/bento/js/jquery.ui.js\" type=\"text/javascript\"></script>\r\n<script src=\"/bento/js/jquery.cycle.min.js\" type=\"text/javascript\"></script>\r\n'),(5,'layout-css','layout-css','<style type=\"text/css\" media=\"all\"> \r\n	@import url(\"/bento/css/reset.css\");\r\n	@import url(\"/bento/css/style.css\");\r\n</style>\r\n'),(6,'blog-pagination','blog-pagination','<!-- CAREFUL -->\r\n\r\n<!-- this block renders pagination for a blog category -->\r\n<div class=\"pagination\">\r\n	{if $page_numb > 1}\r\n		<a href=\"#\">previous page</a>\r\n	{/if}\r\n	\r\n	{if $totalArticles > ($page_numb*$per_page)}\r\n		<a href=\"#\">next page</a>\r\n	{/if}\r\n</div>'),(7,'blog-categories','blog-categories','<div class=\"box\">\n<a href=\"{$httpUrl}{$categoryInfo.url}?rss\"><img src=\"{$httpUrl}/bento/img/btn/btn-rss.gif\" class=\"right pad5\"/></a><h2>Categories</h2>\n<div class=\"content\">\n\n	{blogmenu parent=$currentCategoryIdentifier}\n\n</div>\n</div>'),(8,'user-menu','user-menu','<div class=\"box\">\n<h2>My Account</h2>\n<div class=\"content\">\n{menu parent=\'login\'}\n</div>\n</div>'),(9,'box-sitemap','box-sitemap','<!-- CAREFUL -->\n\n<div class=\"sitemap box\">\n<div class=\"content\">\n	<b>Sitemap</b>\n	{menu}\n</div>\n</div>'),(10,'box-contact','box-contact','<div class=\"box\">\n<h2>Contact</h2>\n<div class=\"content\">\n\n<h5>Mindi Sue Sternblitz-Rubenstein</h5>\n<p>\n972-996-0212 - <a href=\"mailto:mindi.sue@parksassociates.com\">Email</a></p>\n\n<h5>Holly Sprague</h5>\n<p>\n720-987-6614 - <a href=\"mailto:hsprague@gmail.com\">Email</a></p>\n\n</div>\n</div>'),(11,'box-search','box-search','<form method=\"get\" action=\"{$httpUrl}search\">\r\n\r\n	<input type=\"text\" name=\"searchQuery\" value=\"{$searchQuery}\" class=\"text tiny\" id=\"siteSearch\"/> \r\n	<input type=\"submit\" class=\"search-btn\" value=\"SEARCH\"/>\r\n\r\n</form>'),(12,'blog-archive','blog-archive','<div class=\"box\">\n<h2>Blog Archive</h2>\n<div class=\"content\">\n\n	{blog_archive varname=\'archive\' category=$currentCategoryIdentifier}\n		<a href=\"/Blog/category?category_id={$categoryInfo.id}&amp;year={$archive.year}&amp;month={$archive.month}\">\n			{$archive.month|monthName} {$archive.year} ({$archive.count})\n		</a><br/>\n	{/blog_archive}\n\n</div>\n</div>\n'),(13,'blog-archive-yearly','blog-archive-yearly','<div class=\"box\">\n<h2>Yearly Archive</h2>\n<div class=\"content\">\n\n	{blog_archive varname=\'archive\' category=$currentCategoryIdentifier yearly=true}\n		<a href=\"/Blog/category?category_id={$categoryInfo.id}&amp;year={$archive.year}&amp;listView=true\">\n			{$archive.year} ({$archive.count})\n		</a><br/>\n	{/blog_archive}\n\n</div>\n</div>\n');
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_articles`
--

DROP TABLE IF EXISTS `blog_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_articles` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `keyName` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publishDate` datetime NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `status` enum('draft','published','hidden') NOT NULL,
  `layout_id` int(11) NOT NULL,
  `url_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_articles`
--

LOCK TABLES `blog_articles` WRITE;
/*!40000 ALTER TABLE `blog_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_categories` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `keyName` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `displayOrder` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `url_id` int(11) NOT NULL,
  `leftsidebar` text NOT NULL,
  `rightsidebar` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_comments`
--

DROP TABLE IF EXISTS `blog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comments` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `status` enum('pending','approved','spam') NOT NULL,
  `cDate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_comments`
--

LOCK TABLES `blog_comments` WRITE;
/*!40000 ALTER TABLE `blog_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `emailTo` varchar(255) NOT NULL,
  `captcha` tinyint(1) NOT NULL default '1',
  `thanksmsg` text NOT NULL,
  `emailSubject` varchar(255) NOT NULL,
  `emailFrom` varchar(255) NOT NULL,
  `keyName` varchar(45) NOT NULL,
  `includeBasics` tinyint(1) NOT NULL,
  `exactTarget` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_fields`
--

DROP TABLE IF EXISTS `forms_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_fields` (
  `id` int(11) NOT NULL auto_increment,
  `form_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('text','textarea','select','checkbox','radio','label','hidden') NOT NULL default 'text',
  `values` text NOT NULL COMMENT 'comma seperated options for select and radio fields',
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `displayOrder` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL default '0',
  `validateAs` enum('','email') NOT NULL default '',
  `field_name` varchar(45) NOT NULL,
  `checked` tinyint(1) NOT NULL default '0',
  `value` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_fields`
--

LOCK TABLES `forms_fields` WRITE;
/*!40000 ALTER TABLE `forms_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_submitted`
--

DROP TABLE IF EXISTS `forms_submitted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_submitted` (
  `id` int(11) NOT NULL auto_increment,
  `form_id` int(11) NOT NULL default '0',
  `cDate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL default '0',
  `fromPage` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_submitted`
--

LOCK TABLES `forms_submitted` WRITE;
/*!40000 ALTER TABLE `forms_submitted` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_submitted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_submitted_fields`
--

DROP TABLE IF EXISTS `forms_submitted_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_submitted_fields` (
  `id` int(11) NOT NULL auto_increment,
  `field_id` int(11) NOT NULL default '0',
  `submit_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_submitted_fields`
--

LOCK TABLES `forms_submitted_fields` WRITE;
/*!40000 ALTER TABLE `forms_submitted_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_submitted_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendlyurls`
--

DROP TABLE IF EXISTS `friendlyurls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendlyurls` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL,
  `controller` varchar(45) NOT NULL,
  `action` varchar(45) NOT NULL,
  `params` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendlyurls`
--

LOCK TABLES `friendlyurls` WRITE;
/*!40000 ALTER TABLE `friendlyurls` DISABLE KEYS */;
INSERT INTO `friendlyurls` VALUES (1,'/home','Page','Index','a:1:{s:7:\"page_id\";i:1;}','','',''),(2,'/about','Page','Index','a:1:{s:7:\"page_id\";i:2;}','','','');
/*!40000 ALTER TABLE `friendlyurls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layouts`
--

DROP TABLE IF EXISTS `layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layouts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(45) NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layouts`
--

LOCK TABLES `layouts` WRITE;
/*!40000 ALTER TABLE `layouts` DISABLE KEYS */;
INSERT INTO `layouts` VALUES (1,'default','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\"> \r\n<head>\r\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" />\r\n	{block identifier=\'layout-title\'}\r\n	{block identifier=\'layout-js\'}\r\n	{block identifier=\'layout-css\'}\r\n</head> \r\n<body>\r\n\r\n<div id=\"main\">\r\n	\r\n	{block identifier=\'layout-header\'}\r\n	\r\n	<div id=\"site_content\">\r\n		<div id=\"panel\">[hero image here]</div>\r\n		<div class=\"sidebar\">\r\n			{$sidebar_left}\r\n		</div>\r\n		<div id=\"content\">\r\n			{$content}\r\n		</div>\r\n		<div id=\"site_content_bottom\"></div>\r\n	</div>\r\n	\r\n	{block identifier=\'layout-footer\'}\r\n	\r\n</div>\r\n\r\n</body>\r\n</html>');
/*!40000 ALTER TABLE `layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_categories`
--

DROP TABLE IF EXISTS `mb_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `channelid` int(8) default NULL,
  `name` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `displayorder` int(8) default NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `isactive` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_categories`
--

LOCK TABLES `mb_categories` WRITE;
/*!40000 ALTER TABLE `mb_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `mb_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_channels`
--

DROP TABLE IF EXISTS `mb_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_channels` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `displayorder` int(8) default NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `isactive` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_channels`
--

LOCK TABLES `mb_channels` WRITE;
/*!40000 ALTER TABLE `mb_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `mb_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_posts`
--

DROP TABLE IF EXISTS `mb_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_posts` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `userid` bigint(20) unsigned NOT NULL,
  `catid` int(10) unsigned NOT NULL,
  `topic` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `sticky` tinyint(1) NOT NULL default '0',
  `locked` tinyint(1) NOT NULL default '0',
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `isactive` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_posts`
--

LOCK TABLES `mb_posts` WRITE;
/*!40000 ALTER TABLE `mb_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mb_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_replies`
--

DROP TABLE IF EXISTS `mb_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_replies` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `userid` bigint(20) unsigned NOT NULL,
  `postid` bigint(20) unsigned NOT NULL,
  `topic` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `isactive` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_replies`
--

LOCK TABLES `mb_replies` WRITE;
/*!40000 ALTER TABLE `mb_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `mb_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `keyName` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `parent_id` int(11) NOT NULL,
  `displayOrder` int(11) NOT NULL,
  `status` enum('draft','published','hidden') NOT NULL,
  `layout_id` int(11) NOT NULL,
  `url_id` int(11) NOT NULL,
  `type` enum('page','link') NOT NULL default 'page',
  `windowaction` enum('_blank','_self') NOT NULL default '_self',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Home','home','',0,0,'published',1,1,'page','_self'),(2,'About','about','<p>\r\n	All about us</p>\r\n',0,1,'published',1,2,'page','_self');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) NOT NULL,
  `controller` varchar(45) NOT NULL,
  `action` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searches`
--

DROP TABLE IF EXISTS `searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searches` (
  `id` int(11) NOT NULL auto_increment,
  `searchQuery` varchar(255) NOT NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sidebars`
--

DROP TABLE IF EXISTS `sidebars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sidebars` (
  `id` int(11) NOT NULL auto_increment,
  `page_id` int(11) NOT NULL,
  `location` enum('left','right') NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sidebars`
--

LOCK TABLES `sidebars` WRITE;
/*!40000 ALTER TABLE `sidebars` DISABLE KEYS */;
INSERT INTO `sidebars` VALUES (1,1,'left',''),(2,1,'right',''),(3,2,'left',''),(4,2,'right','');
/*!40000 ALTER TABLE `sidebars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `key` varchar(45) NOT NULL,
  `value` varchar(255) NOT NULL,
  `group` varchar(45) NOT NULL,
  `values` varchar(255) NOT NULL COMMENT 'if populated, a select list is created, else it assumes text entry',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'Articles per page','How many articles to display per page','per-page','5','blog',''),(2,'Category URL','The default URL prefix for blog categories','category-url','/blog/category/','blog',''),(3,'Page URL','The default URL prefix for CMS pages','page-url','/','cms',''),(4,'Article URL','The default URL prefix for blog articles','article-url','/blog/article/','blog',''),(5,'Category Layout','The default category layout','category-layout','blog-category','blog',''),(6,'Article Layout','The default article layout','article-layout','blog-article','blog',''),(14,'Default Meta Title','Default meta title if custom one not set','default-meta-title','title','meta',''),(15,'Default Meta Description','Default meta description if custom one not set','default-meta-description','description','meta',''),(16,'Default Meta Keywords','Default meta keywords if custom ones not set','default-meta-keywords','keywords','meta',''),(19,'Admin Email','Admin to receive emails','admin-email','info@example.com','admin',''),(29,'Articles per page (admin)','How many articles to display per page (in admin)','per-page-admin','20','blog','');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slideshow_shows`
--

DROP TABLE IF EXISTS `slideshow_shows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slideshow_shows` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `delay` double(2,1) NOT NULL,
  `transition` varchar(25) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `keyName` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slideshow_shows`
--

LOCK TABLES `slideshow_shows` WRITE;
/*!40000 ALTER TABLE `slideshow_shows` DISABLE KEYS */;
/*!40000 ALTER TABLE `slideshow_shows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slideshow_slides`
--

DROP TABLE IF EXISTS `slideshow_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slideshow_slides` (
  `id` int(11) NOT NULL auto_increment,
  `show_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `displayOrder` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `windowaction` varchar(25) NOT NULL default '_self',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slideshow_slides`
--

LOCK TABLES `slideshow_slides` WRITE;
/*!40000 ALTER TABLE `slideshow_slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `slideshow_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templates` (
  `id` int(11) NOT NULL auto_increment,
  `group` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `keyName` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `left_sidebar` text NOT NULL,
  `right_sidebar` text NOT NULL,
  `displayOrder` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (1,'content','user profile','user-profile','<script type=\"text/javascript\" src=\"/frontend/views/js/userProfile.js\"></script>\r\n\r\n<h1>My Profile</h1>\r\n<div class=\"pad10\">\r\n{if $message}\r\n<div class=\"success\">{$message}</div><br/>\r\n{/if}\r\n<div>\r\n	<form method=\"post\" action=\"/User/saveprofile\" id=\"userprofile_form\">\r\n		<input type=\"hidden\" name=\"user_id\" value=\"{$userInfo.id}\"/>\r\n		<table width=\"100%\" class=\"form\">\r\n			<tr>\r\n				<td width=\"20%\"><label>Email</label></td>\r\n				<td><input name=\"user_email\" value=\"{$userInfo.email}\" class=\"text lrg\" readonly/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Company</label></td>\r\n				<td><input type=\"text\" name=\"user_company\" class=\"text lrg\" value=\"{$userInfo.company}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Title</label></td>\r\n				<td><input type=\"text\" name=\"user_title\" class=\"text lrg\" value=\"{$userInfo.title}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>First Name</label></td>\r\n				<td><input type=\"text\" name=\"user_fName\" class=\"text lrg\" value=\"{$userInfo.fName}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Last Name</label></td>\r\n				<td><input type=\"text\" name=\"user_lName\" class=\"text lrg\" value=\"{$userInfo.lName}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Phone</label></td>\r\n				<td><input type=\"text\" name=\"user_phone\" class=\"text lrg\" value=\"{$userInfo.phone}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Address</label></td>\r\n				<td><input type=\"text\" name=\"user_address\" class=\"text lrg\" value=\"{$userInfo.address}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Address 2</label></td>\r\n				<td><input type=\"text\" name=\"user_address2\" class=\"text lrg\" value=\"{$userInfo.address2}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Country</label></td>\r\n				<td><input type=\"text\" name=\"user_country\" class=\"text lrg\" value=\"{$userInfo.country}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>City</label></td>\r\n				<td><input type=\"text\" name=\"user_city\" class=\"text lrg\" value=\"{$userInfo.city}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Province</label></td>\r\n				<td><input type=\"text\" name=\"user_province\" class=\"text lrg\" value=\"{$userInfo.province}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Zip</label></td>\r\n				<td><input type=\"text\" name=\"user_zip\" class=\"text lrg\" value=\"{$userInfo.zip}\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label></label></td>\r\n				<td><input type=\"submit\" value=\"Save\" class=\"button-blue\"/></td>\r\n			</tr>\r\n		</table>\r\n	</form>\r\n</div>\r\n</div>','{block identifier=\'user-menu\'}','',0),(5,'content','user forgot password','user-forgotpassword','<h1>Forgot Password</h1>\n<div class=\"pad10\">\n{if $message}\n	<div class=\"success message\">{$message}</div>\n{/if}\n{if $errorMsg}\n	<div class=\"error message\">{$errorMsg}</div>\n{/if}\n	\n	<form method=\"post\" action=\"/User/forgotpassword\">\n	<input type=\"hidden\" name=\"resetpassword\" value=\"1\"/>\n		<table width=\"100%\" class=\"form\">\n			<tr>\n				<td width=\"20%\"><label>Email Address</label></td>\n				<td><input type=\"text\" name=\"email\" class=\"text lrg\"/></td>\n			</tr>\n			<tr>\n				<td><label></label></td>\n				<td><input type=\"submit\" value=\"Reset Password\" class=\"button-blue\"/></td>\n			</tr>\n		</table>\n	</form>\n\n</div>','','',0),(6,'content','user login','user-login','<script src=\"/frontend/views/js/userRegister.js\" type=\"text/javascript\"></script>\r\n\r\n<h1>Account Login</h1>\r\n\r\n<div class=\"pad10\">\r\n\r\n{if $errorMsg}<div class=\"error message\">{$errorMsg}</div>{/if}\r\n<form method=\"post\" action=\"/User/login\">\r\n	<input type=\"hidden\" name=\"returnUrlRequest\" value=\"{$urlrequest}\"/>\r\n	<input type=\"hidden\" name=\"dologin\" value=\"1\"/>\r\n	\r\n	<table width=\"100%\" class=\"form\">\r\n		<tr>\r\n			<td width=\"20%\"><label>Email</label></td>\r\n			<td><input type=\"text\" name=\"email\" class=\"text med\"/></td>\r\n		</tr>\r\n		<tr>\r\n			<td><label>Password</label></td>\r\n			<td><input type=\"password\" name=\"password\" class=\"text med\"/></td>\r\n		</tr>\r\n		<tr>\r\n			<td></td>\r\n			<td><input type=\"submit\" class=\"button-blue\" value=\"login\"/></td>\r\n		</tr>\r\n		<tr>\r\n			<td></td>\r\n			<td><a href=\"/User/register?returnUrlRequest={$urlrequest}\">Don\'t have an account? Register here.</a><br/><a href=\"/User/forgotpassword\">Forgot Password</a></td>\r\n		</tr>\r\n	</table>\r\n	\r\n</form>\r\n\r\n</div>\r\n','','{block identifier=\"box-core-research-areas\"}',0),(7,'content','user register','user-register','<script type=\"text/javascript\" src=\"/frontend/views/js/userRegister.js\"></script>\r\n\r\n<h1>Register for Account</h1>\r\n\r\n<div class=\"pad10\">\r\n	\r\n	{if $errorMsg}\r\n		<ul>\r\n		{if is_array($errorMsg)}\r\n			{foreach from=$errorMsg item=error}\r\n				<li>{$error}</li>\r\n			{/foreach}\r\n		{else}\r\n			<li>{$errorMsg}</li>\r\n		{/if}\r\n		<ul>\r\n	{/if}\r\n	\r\n	<form method=\"post\" action=\"/User/register\" id=\"userRegister_form\">\r\n	<input type=\"hidden\" name=\"doregister\" value=\"1\"/>\r\n	<input type=\"hidden\" name=\"returnUrlRequest\" value=\"{$urlrequest}\"/>\r\n	\r\n		<table width=\"100%\" class=\"form\">\r\n			<tr>\r\n				<td width=\"20%\"><label>Email</label></td>\r\n				<td><input type=\"text\" name=\"user_email\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Password</label></td>\r\n				<td><input type=\"password\" name=\"user_password\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Verify Password</label></td>\r\n				<td><input type=\"password\" name=\"user_password2\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Company</label></td>\r\n				<td><input type=\"text\" name=\"user_company\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Title</label></td>\r\n				<td><input type=\"text\" name=\"user_title\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>First Name</label></td>\r\n				<td><input type=\"text\" name=\"user_fName\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Last Name</label></td>\r\n				<td><input type=\"text\" name=\"user_lName\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Phone</label></td>\r\n				<td><input type=\"text\" name=\"user_phone\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Address</label></td>\r\n				<td><input type=\"text\" name=\"user_address\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Address 2</label></td>\r\n				<td><input type=\"text\" name=\"user_address2\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Country</label></td>\r\n				<td><input type=\"text\" name=\"user_country\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>City</label></td>\r\n				<td><input type=\"text\" name=\"user_city\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Province</label></td>\r\n				<td><input type=\"text\" name=\"user_province\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Zip</label></td>\r\n				<td><input type=\"text\" name=\"user_zip\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label></label></td>\r\n				<td><input type=\"submit\" value=\"Register\" class=\"button-blue\"/></td>\r\n			</tr>\r\n		</table>\r\n\r\n	</form>\r\n\r\n</div>','','{block identifier=\"box-core-research-areas\"}',0),(12,'blog','article','blog-article','<div class=\"articles\">\n\n	<h2 class=\"blog-date\">{$articleInfo.publishDate|date_format:\"%A, %B %d, %G | %I:%M %p\"}</h2>\n\n		<p class=\"blog-title\">{$articleInfo.title}</p>\n\n		<div class=\"pad20\">\n	\n			<p class=\"blog-article\">{$articleInfo.article}</p>\n\n			<p class=\"blog-tags\">\n			Tags: \n			{foreach from=$articleTags item=tag}\n			    <b>{$tag.tag}</b>, \n			{/foreach}\n			</p>\n\n			<p class=\"blog-author\">Posted by <b><a href=\"mailto:{$articleAuthor.email}\">{$articleAuthor.fullName}</a>{if $articleAuthor.title}, {$articleAuthor.title}{/if}</b></p>\n\n			<p>\n			{if $nextArticle}\n				<b>Next:</b> <a href=\"{$nextArticle.url}\">{$nextArticle.title}</a><br/>\n			{/if}\n\n			{if $prevArticle}\n				<b>Previous:</b> <a href=\"{$prevArticle.url}\">{$prevArticle.title}</a><br/>\n			{/if}\n			</p>\n\n	</div>\n\n<h4>Comments</h4>\n\n<div class=\"pad20\">\n\n<ul class=\"blog-comments\">\n{foreach from=$articleComments item=comment}\n	<li>\n		<p class=\"blog-comment-user\"><b>{$comment.name}</b> wrote</p>\n		<p class=\"blog-comment\">{$comment.comment}</p>\n		<p class=\"blog-comment-date\"><span class=\"small\">on {$comment.cDate|date_format:\"%c\"}</span></p>\n	</li>\n{foreachelse}\n	Be the first to leave a comment.\n{/foreach}\n</ul>\n\n</div>\n\n<h4>Post a Comment</h4>\n\n<div class=\"pad20\">\n\n<a name=\"comment\"></a>\n{if $commentSubmitted}\n	<div class=\"success\">Your comment has been submitted and is awaiting approval.</div>\n{/if}\n\n<form method=\"post\" action=\"/blog/comment\" id=\"comment\">\n<input type=\"hidden\" name=\"article_id\" value=\"{$articleInfo.id}\">\n<input type=\"hidden\" name=\"user_id\" value=\"{if $loggedIn}{$UserInfo.id}{else}0{/if}\">\n\n<table width=\"100%\" class=\"table\">\n	<tr>\n		<td width=\"25%\"><strong>Display Name</strong></td>\n		<td><input type=\"text\" name=\"name\" value=\"{if $UserInfo}{$UserInfo.fName} {$UserInfo.lName}{/if}\" class=\"text med\"> <input type=\"checkbox\" name=\"anonymous\" value=\"1\"> Post Anonymously?</td>\n	</tr>\n	<tr>\n		<td><strong>Comment</strong></td>\n		<td><textarea name=\"comment\" class=\"textarea\" class=\"textarea sml\"></textarea></td>\n	</tr>\n	<tr>\n		<td></td>\n		<td><input type=\"submit\" value=\"Submit\" class=\"button-blue\"></td>\n	</tr>\n</table>\n\n</form>\n\n</div>\n\n</div>','','{block identifier=\"blog-categories\"}',0),(13,'blog','articles','blog-articles','<h1 class=\"blog-cat\">{$pageTitle}</h1>\n\n{foreach from=$articles item=article}\n	<div class=\"articles\">\n		<h2 class=\"blog-date\">{$article.publishDate|date_format:\"%A, %B %d, %G | %I:%M %p\"}</h2>\n		<p class=\"blog-title\"><a href=\"{$article.url}\">{$article.title}</a></p>\n		<div class=\"pad10\">\n			<p class=\"blog-article\">{$article.article}</p>\n			<p class=\"blog-author\">Posted by <b><a href=\"mailto:{$article.author.email}\">{$article.author.fullName}</a>, {$article.author.title}</b></p>\n		</div>\n	</div>\n{foreachelse}\n	<p>No articles</p>\n{/foreach}\n\n<div class=\"pages\">\n		{if $page_numb > 1}<a href=\"{$httpUrl}Blog/category?page_numb={$page_numb-1}&amp;category_id={$categoryInfo.id}&amp;year={$year}&amp;month={$month}\">Prev</a>{/if}\n		Page(s): \n			<select name=\"pages\" onchange=\"document.location = \'{$httpUrl}Blog/category?page_umb=\' + $(this).val() + \'&amp;category_id={$categoryInfo.id}&amp;year={$year}&amp;month={$month}\';\">\n					{section name=pages loop=$totalPages}\n						<option value=\"{$smarty.section.pages.iteration}\" {if $smarty.section.pages.iteration == $page_numb}selected{/if}>{$smarty.section.pages.iteration}</option>\n					{/section}\n			</select>\n			&nbsp; of &nbsp; {$totalPages}\n		{if $totalPages > $page_numb}<a href=\"{$httpUrl}Blog/category?page_numb={$page_numb+1}&amp;category_id={$categoryInfo.id}&amp;year={$year}&amp;month={$month}\">Next</a>{/if}\n	</div><!-- paginate -->','','{block identifier=\'blog-categories\'}\n{block identifier=\'blog-archive\'}',0),(19,'content','form','form','<div class=\"box\">\r\n<div class=\"content\">\r\n{if $formErrors}\r\n	<div class=\"error message\">All fields highlighted in red are required. Please try again.</div><br/>\r\n{/if}\r\n{if $formSubmitted}\r\n	<div class=\"success\" style=\"display: none;\">{$formInfo.thanksmsg}</div>\r\n{else}\r\n	\r\n	<form method=\"post\" action=\"/Form/submit\" id=\"form_{$formInfo.id}\">\r\n	<input type=\"hidden\" name=\"returnUrlRequest\" value=\"{$urlrequest}\"/>\r\n	<input type=\"hidden\" name=\"formSubmit[id]\" value=\"{$formInfo.id}\"/>\r\n	<input type=\"hidden\" name=\"pageTitle\" value=\"{$pageTitle}\"/>\r\n	<input type=\"hidden\" name=\"exactTarget\" value=\"{$formInfo.exactTarget}\"/>\r\n	\r\n	{if $formInfo.user_fields}\r\n		{if $loggedIn}\r\n			<p><b>Your profile information will also be submitted.</b></p>\r\n			{foreach from=$formInfo.user_fields item=userField}\r\n				{if !empty($userField.value)}\r\n				<input type=\"hidden\" name=\"formSubmit[userfields][{$userField.id}]\" value=\"{$userField.value}\"/>\r\n				{/if}\r\n			{/foreach}\r\n		{else}\r\n			<div class=\"note\">Request more info by filling out the form below as a Guest, or <a href=\"/User/login?returnUrlRequest={$urlrequest}\">Login</a> / <a href=\"/User/register?returnUrlRequest={$urlrequest}\">Register</a> to skip.</div>\r\n			\r\n			<div class=\"user_fields\">\r\n			<div class=\"pad10\">\r\n			<table width=\"100%\">\r\n			{foreach from=$formInfo.user_fields item=formField}\r\n				{if $formField.type == \'label\'}\r\n				{/if}\r\n				\r\n				{if $formField.type == \'text\'}\r\n				<tr>\r\n					<td width=\"30%\"><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n					<td><input type=\"text\" name=\"formSubmit[userfields][{$formField.id}]\" class=\"text {if $formField.hasError}error{/if}\"/></td>\r\n				</tr>\r\n				{/if}\r\n				\r\n				{if $formField.type == \'textarea\'}\r\n				<tr>\r\n					<td colspan=\"2\">&nbsp;</td>\r\n				</tr>\r\n				<tr>\r\n					<td><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n					<td><textarea name=\"formSubmit[userfields][{$formField.id}]\" {if $formField.width} cols=\"{$formField.width}\"{/if} {if $formField.height} rows=\"{$formField.height}\"{/if} class=\"textarea {if $formField.hasError}error{/if}\"></textarea></td>\r\n				</tr>\r\n				{/if}\r\n			\r\n				{if $formField.type == \'select\'}\r\n				<tr>\r\n					{if $formField.values}\r\n						<td><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n						<td><select name=\"formSubmit[userfields][{$formField.id}]\" class=\"select sml {if $formField.hasError}error{/if}\">\r\n						{assign var=values value=\',\'|explode:$formField.values}\r\n						{foreach from=$values item=value}\r\n							<option value=\"{$value}\">{$value}</option>\r\n						{/foreach}\r\n						</select></td>\r\n					{/if}\r\n				{/if}\r\n			\r\n				{if $formField.type == \'checkbox\'}\r\n				<tr>\r\n					<td><input type=\"checkbox\" name=\"formSubmit[userfields][{$formField.id}]\" value=\"{$formField.value}\" {if $formField.checked}checked=\"checked\"{/if} class=\"/></td>\r\n					<td class=\"{if $formField.hasError}error{/if}\">{$formField.name} {if $formField.required}*{/if}</td>\r\n				</tr>\r\n				{/if}\r\n				\r\n				{if $formField.type == \'radio\'}\r\n					{if $formField.values}\r\n						<tr>\r\n							<td><label class=\"{if $formField.hasError}error{/if}\">{$formField.name} {if $formField.required}*{/if}</label></td>\r\n						{assign var=values value=\',\'|explode:$formField.values}\r\n							<td>\r\n						{foreach from=$values item=value}\r\n							<input type=\"radio\" name=\"formSubmit[userfields][{$formField.id}]\" value=\"{$value}\"/> {$value} \r\n						{/foreach}\r\n						</td>\r\n						</tr>\r\n					{/if}\r\n				{/if}\r\n			{/foreach}\r\n			</table>\r\n			</div>\r\n			</div>\r\n		{/if}\r\n	{/if}\r\n	\r\n	\r\n		<table width=\"100%\" class=\"form-table\">\r\n		{foreach from=$formInfo.fields item=formField}\r\n			\r\n			{if $formField.type == \'label\'}\r\n				<tr>\r\n					<td colspan=\"2\"><label>{$formField.name}</label></td>\r\n				</tr>\r\n			{/if}\r\n	\r\n			{if $formField.type == \'text\'}\r\n			<tr>\r\n				<td width=\"20%\"><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n				<td><input type=\"text\" name=\"formSubmit[fields][{$formField.id}]\" class=\"text{if $formField.hasError} error{/if}\" value=\"{$formField.value}\"/></td>\r\n			</tr>\r\n			{/if}\r\n	\r\n			{if $formField.type == \'textarea\'}\r\n			<tr>\r\n					<td colspan=\"2\">&nbsp;</td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"2\"><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"2\"><textarea name=\"formSubmit[fields][{$formField.id}]\" {if $formField.width} cols=\"{$formField.width}\"{/if} {if $formField.height} rows=\"{$formField.height}\"{/if}{if $formField.hasError} class=\"error\"{/if}>{$formField.value}</textarea></td>\r\n			</tr>\r\n			{/if}\r\n\r\n			{if $formField.type == \'select\'}\r\n				{if $formField.values}\r\n				<tr>\r\n					<td colspan=\"2\"><label>{$formField.name} {if $formField.required}*{/if}</label></td>\r\n				</tr>\r\n				<tr>\r\n					<td colspan=\"2\"><select name=\"formSubmit[fields][{$formField.id}]\" class=\"select med{if $formField.hasError}error{/if}\">\r\n					{assign var=values value=\',\'|explode:$formField.values}\r\n					{foreach from=$values item=value}\r\n						<option value=\"{$value}\" {if $value==$formField.value}selected=\"selected\"{/if}>{$value}</option>\r\n					{/foreach}\r\n					</select></td>\r\n				</tr>\r\n				{/if}\r\n			{/if}\r\n\r\n			{if $formField.type == \'checkbox\'}\r\n				<tr>\r\n					<td colspan=\"2\">{if $formField.hasError}<b class=\"error\">required</b>{/if}<input type=\"checkbox\" name=\"formSubmit[fields][{$formField.id}]\" value=\"{$formField.value}\" {if $formField.checked}checked=\"checked\"{/if}{if $formField.hasError} class=\"error\"{/if}/> {$formField.name} {if $formField.required}*{/if}</td>\r\n				</tr>\r\n			{/if}\r\n	\r\n			{if $formField.type == \'radio\'}\r\n				<tr>\r\n					<td colspan=\"2\">&nbsp;</td>\r\n				</tr>\r\n				{if $formField.values}\r\n				<tr>\r\n					<td colspan=\"2\"><label class=\"{if $formField.hasError}error{/if}\">{$formField.name} {if $formField.required}*{/if}</label>\r\n				</tr>\r\n				<tr>\r\n					<td colspan=\"2\">\r\n					{assign var=values value=\',\'|explode:$formField.values}\r\n					{foreach from=$values item=value}\r\n						<input type=\"radio\" name=\"formSubmit[fields][{$formField.id}]\" value=\"{$value}\" {if $formField.checked}checked=\"checked\"{/if}{if $formField.hasError} class=\"error\"{/if}/> {$value}<br/>\r\n					{/foreach}\r\n					</td>\r\n				</tr>\r\n				{/if}\r\n			{/if}\r\n\r\n		{/foreach}\r\n		</table>\r\n		\r\n		<br/>\r\n		\r\n		<input type=\"submit\" value=\"Submit\" class=\"button-blue\"/><br/><br/>\r\n		<div class=\"clear\"></div>\r\n	\r\n	\r\n	</form>\r\n{/if}\r\n</div>\r\n</div>\r\n\r\n','','',0),(26,'content','user change password','user-changepassword','<h1>Change Password</h1>\r\n<div class=\"pad10\">\r\n{if $changedpassword}\r\n	<div class=\"message\">Your password has been successfully updated.</div>\r\n{else}\r\n	{if $errorMsg}\r\n		<div class=\"error message\">{$errorMsg}</div>\r\n	{/if}\r\n	\r\n	<form method=\"post\" action=\"/User/changepassword\">\r\n	<input type=\"hidden\" name=\"changepassword\" value=\"1\"/>\r\n		<table width=\"100%\" class=\"form\">\r\n			<tr>\r\n				<td width=\"20%\"><label>Current Password</label></td>\r\n				<td><input type=\"password\" name=\"orignal_pw\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>New Password</label></td>\r\n				<td><input type=\"password\" name=\"password\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label>Verify Password</label></td>\r\n				<td><input type=\"password\" name=\"password2\" class=\"text lrg\"/></td>\r\n			</tr>\r\n			<tr>\r\n				<td><label></label></td>\r\n				<td><input type=\"submit\" value=\"Save\" class=\"button-blue\"/></td>\r\n			</tr>\r\n		</table>\r\n	</form>\r\n	\r\n{/if}\r\n</div>','{block identifier=\'user-menu\'}','',0),(29,'emails','email-sendform','email-sendform','<table width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" border=\"0\">\n{foreach from=$formFields item=field}\n	<tr>\n		<td width=\"20%\"><b>{$field.name}</b></td>\n		<td>{$field.value}</td>\n	</tr>\n{/foreach}\n</table>','','',0),(30,'emails','email-register','email-register','<h1>New User Registered</h1>\n<div class=\"pad15\">\n\n	<table width=\"100%\">\n		<tr>\n			<td>First Name</td>\n			<td>{$userInfo.fName}</td>\n		</tr>\n		<tr>\n			<td>Last Name</td>\n			<td>{$userInfo.lName}</td>\n		</tr>\n		<tr>\n			<td>Company</td>\n			<td>{$userInfo.company}</td>\n		</tr>\n		<tr>\n			<td>Title</td>\n			<td>{$userInfo.title}</td>\n		</tr>\n		<tr>\n			<td>Phone</td>\n			<td>{$userInfo.phone}</td>\n		</tr>\n		<tr>\n			<td>Email</td>\n			<td>{$userInfo.email}</td>\n		</tr>\n		<tr>\n			<td>Address</td>\n			<td>{$userInfo.address}</td>\n		</tr>\n		<tr>\n			<td>Address 2</td>\n			<td>{$userInfo.address2}</td>\n		</tr>\n		<tr>\n			<td>Country</td>\n			<td>{$userInfo.country}</td>\n		</tr>\n		<tr>\n			<td>State/Province</td>\n			<td>{$userInfo.province}</td>\n		</tr>\n		<tr>\n			<td>City</td>\n			<td>{$userInfo.city}</td>\n		</tr>\n		<tr>\n			<td>Zip</td>\n			<td>{$userInfo.zip}</td>\n		</tr>\n	</table>\n\n</div>','','',0),(31,'emails','email-login','email-login','<h1>Primary CS User Logged In</h1>\r\n<div class=\"pad15\">\r\n	<p>\r\n	{$userInfo.fName} {$userInfo.lName} at {$userInfo.company} logged in at {$userInfo.lastLogin}<br/>\r\n	</p>\r\n	<table width=\"100%\">\r\n		<tr>\r\n			<td>First Name</td>\r\n			<td>{$userInfo.fName}</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Last Name</td>\r\n			<td>{$userInfo.lName}</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Company</td>\r\n			<td>{$userInfo.company}</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Title</td>\r\n			<td>{$userInfo.title}</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Phone</td>\r\n			<td>{$userInfo.phone}</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Email</td>\r\n			<td>{$userInfo.email}</td>\r\n		</tr>\r\n		\r\n	</table>\r\n\r\n</div>','','',0),(36,'content','search','search','<h1>Search</h1>\n\n<form method=\"get\" action=\"{$httpUrl}search\">\n\n<div class=\"search\">\n<div class=\"pad20\">\n\n<table width=\"100%\">\n	<tr>\n		<td><input type=\"text\" name=\"searchQuery\" value=\"{$searchQuery}\" class=\"text lrg\"/></td>\n		<td width=\"10\"><input type=\"submit\" class=\"button-blue right\" value=\"search\"/></td>\n	</tr>\n	<tr>\n		<td align=\"left\">\n		<ul>\n			<li><b>Filter Search:</b></li>\n			<li><input type=\"checkbox\" name=\"searchForType[]\" value=\"Shop-Product\"/> Industry Reports</li>\n			<li><input type=\"checkbox\" name=\"searchForType[]\" value=\"Page-Index\"/> Content Page</li>\n			<li><input type=\"checkbox\" name=\"searchForType[]\" value=\"Blog-Article\"/> Blogs</li>\n			<li><input type=\"checkbox\" name=\"searchForType[]\" value=\"Shop-Whitepaper\"/> Whitepapers</li>\n			<li><input type=\"checkbox\" name=\"searchForType[]\" value=\"Shop-Webcast\"/> Webcasts</li>\n		</ul>\n		</td>\n		<td></td>\n	</tr>\n</table>\n</div>\n</div>\n\n</form>\n\n<div class=\"clear\"></div>\n\n{if $searchQuery}\n<div class=\"search-results\">\n<div class=\"pad20\">\n	{if !empty($searchResults)}\n		<ol>\n		{foreach from=$searchResults item=result}\n			<li>\n				<a href=\"{$result.url}\">{if $result.title}{$result.title}{else}-untitled-{/if}</a> <span class=\"medium\">{$result.type}</span><br/>\n				<span class=\"small\">{if $result.description}{$result.description}{else}-no description-{/if}</span><br/>\n				<span class=\"small\">{$httpUrl|substr:0:-1}{$result.url}</span>\n			</li>\n		{/foreach}\n		</ol>\n	{else}\n		<h2>No results found</h2>\n	{/if}\n</div>\n</div>\n{/if}','','{block identifier=\"box-primary-research\"}\n\n{block identifier=\"box-white-papers\"}\n\n{block identifier=\"box-newsletters\"}',0),(37,'emails','email-changepassword','email-changepassword','<h1>Your password has been updated</h1>\n<div class=\"pad15\">\n	<p>\n	This email is to confirm your password change for {$userInfo.email} on the Parks Associates website. If you did not authorize this change, please contact us immediately. \n	</p>\n</div>','','',0),(38,'emails','email-forgotpassword','email-forgotpassword','<h1>Your password has been reset</h1>\n<div class=\"pad15\">\n	<p>\n	Your password has been reset to a new random password for the Parks Associates website.<br/>\n	<br/>\n	Email: {$userInfo.email}<br/>\n	New Password: {$userInfo.newPassword}<br/>\n	<br/>\n	<b>Please login and change your password to a password you will remember.</b><br/>\n	</p>\n</div>','','',0),(41,'blog','articles-list','blog-articles-list','<h1 class=\"blog-cat\">{$pageTitle}</h1>\n\n<ul>\n\n<div class=\"articles\">\n{foreach from=$articles item=article}\n		<div class=\"pad10\">\n			{$article.publishDate|date_format:\"%A, %B %d, %G\"}<br/>\n			<a href=\"{$article.url}\">{$article.title}</a>\n		</div>\n{foreachelse}\n	<p>No articles</p>\n{/foreach}\n</div>','','',0);
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `fName` varchar(45) NOT NULL,
  `lName` varchar(45) NOT NULL,
  `title` varchar(45) NOT NULL,
  `cDate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL default '1',
  `lastLogin` timestamp NOT NULL default '0000-00-00 00:00:00',
  `lockout` timestamp NOT NULL default '0000-00-00 00:00:00',
  `loginattempts` int(11) NOT NULL,
  `type` enum('user','admin') NOT NULL default 'user',
  `phone` varchar(45) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(45) NOT NULL,
  `province` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `zip` varchar(45) NOT NULL,
  `company` varchar(45) NOT NULL,
  `activateString` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@example.com','5f4dcc3b5aa765d61d8327deb882cf99','Bento','CMS','Admin','2011-01-27 23:56:30',1,'2011-06-06 00:07:28','0000-00-00 00:00:00',0,'admin','','','','','','','','','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permissions`
--

DROP TABLE IF EXISTS `users_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permissions` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `users_id` (`user_id`),
  KEY `permissions_id` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permissions`
--

LOCK TABLES `users_permissions` WRITE;
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-06-05 20:07:29
